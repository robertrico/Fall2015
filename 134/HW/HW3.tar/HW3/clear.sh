#!/bin/bash
mysql -uroot -proot homework3 < clear_tables.sql
