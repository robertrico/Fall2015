#!/bin/bash
mysql -uroot -proot homework3 < 4_drop_all.sql
