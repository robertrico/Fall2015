DELETE FROM Prescription;
DELETE FROM Drug;
DELETE FROM Ph_company;
DELETE FROM Doctor;
