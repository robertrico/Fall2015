#!/bin/bash
mysql -uroot -proot homework3 < 1_create_table.sql
