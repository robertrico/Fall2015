#!/bin/bash
mysql -uroot -proot homework3 < 2_populate_db.sql
